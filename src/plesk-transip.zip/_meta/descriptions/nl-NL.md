Deze extensie integreert Plesk met TransIP, zodat je:

- alle informatie van DNS-zones tussen Plesk en TransIP kunt synchroniseren.
- DNS updates automatisch kunt versturen naar TransIP.
