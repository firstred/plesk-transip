This extension integrates Plesk with TransIP, so you can:

- Synchronize all DNS zones information between Plesk and TransIP name servers at once.
- Push DNS updates automatically to TransIP.
